package ExampleInheritance;
public class Credit extends Card {

    private float usage =0;
    private float percentage;
    private Account account;
    private int attempts = 0;

    public Credit(float percentage, Account account,int CSV) {
        this.percentage = percentage;
        this.account = account;
        setAccount(account);
        setCardCSV(CSV);
    }

    public void makePayment(float amount,int CSV){
        if(getCardCSV() == CSV & attempts <3){
            attempts = 0;
            if(amount > calculateMaxLimit()){
                printMessage("Balance too low to make payment");
            }else{
                getAccount().setBalance(getAccount().getBalance()-amount);
                this.usage += amount;
                setPoints(amount);
                printMessage("Payment Successful");
                printMessage("Updated Account Balance is Rs ",getAccount().getBalance());
            }
        }
        else{            
            attempts++;
            if(attempts >=3){
                printMessage("Card disabled. Please contact Bank");
            }else{
                printMessage("Authentical Failed");
            }      
        }
    }

    protected void setPoints(float amount){
        int pointsCalc = (int)amount / 100; 
        points = pointsCalc;
    }
    
    private float calculateMaxLimit(){
        return this.percentage*getAccount().getBalance();
    }

    public float getUsage() {
        return this.usage;
    }

    public float getPercentage() {
        return this.percentage;
    }

    public Account getAccount(){
        return this.account;
    }

    @Override
    public String toString() {
        return "{" +
            " usage='" + getUsage() + "'" +
            ", percentage='" + getPercentage() + "'" +
            ", account='" + getAccount().toString() + "'" +
            ", Membership Points= "+ points +
            "}";
    }

}

    
