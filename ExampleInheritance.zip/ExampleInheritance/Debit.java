package ExampleInheritance;

public class Debit extends Card{
    private float usage =0;
    private Account account;
    private int attempts = 0;

    public Debit(Account account,int CSV) {
        this.account = account;
        setCardCSV(CSV);
    }

    public float getUsage() {
        return this.usage;
    }

    public Account getAccount() {
        return this.account;
    }

    public void makePayment(float amount,int CSV){
        float balance = getAccount().getBalance();
        if(getCardCSV() == CSV  & attempts <3){
            attempts = 0;
            if(amount > balance){
                printMessage("Balance too low to make payment");
            }else{
                getAccount().setBalance(balance-amount);
                this.usage += amount;
                setPoints(amount);
                printMessage("Payment Successful.");
                printMessage("Updated Account Balance is Rs ",getAccount().getBalance());
            }
        }else{
            attempts++;
            if(attempts >=3){
                printMessage("Card disabled. Please contact Bank");
            }else{
                printMessage("Authentical Failed");
            }
        }
    }

    protected void setPoints(float amount){
        int pointsCalc = (int)amount / 250; 
        points = pointsCalc;
    }


    @Override
    public String toString() {
        return "{" +
            " usage='" + usage + "'" +
            ", account='" + account + "'" +
            ", Membership Points= "+ points +
            "}";
    }




}
